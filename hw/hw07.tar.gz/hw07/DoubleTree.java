import java.util.NoSuchElementException;

/* YOUR NAME HERE
 * This is the place to write any sources you used etc.
 */
public class DoubleTree implements AddMax {
  // TODO
}
