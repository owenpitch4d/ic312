IC312 Project 2: Pills

*** Please fill in this file completely before submitting. ***

Name:
Alpha:

Describe any help or outside resources used (or write "None"):

Estimate how well you did on each part, on a scale of
0 (nothing) to 5 (perfectly correct and efficient):
  Part 1 (TreeMap):    ? / 5
  Part 2 (Pharmacies): ? / 5
  Part 3 (TopK):       ? / 5
  Part 4 (Zips):       ? / 5
  Code style:          ? / 5
  Bonus (faster):      ? / 5

Please explain your self-assessment scores above:


What did you do to thoroughly test your own code?


What part or aspect of this project was the most challenging?


Explain what you did for the bonus (if anything):


What part or aspect of this project was the most tedious or
uninteresting?


How did the difficulty and time required for this project
compare to those in your other CS/IT courses?


Any other comments for your instructor?
