IC312 Project 1: Text Editor

*** Please fill in this file completely before submitting. ***

Name:
Alpha:

Describe any help or outside resources used (or write "None"):


Which interface did you implement using linked lists, and why?


Which interface did you implement using arrays, and why?


What part or aspect of this project was the most challenging?


What part or aspect of this project was the most tedious or
uninteresting?


How did the difficulty and time required for this project
compare to those in your other CS/IT courses?


Any other comments for your instructor?
